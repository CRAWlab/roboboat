TODO:

1. Create a new directory called `roboboat_tf` via `catkin_create_pkg` in `roboboat_ws/src/roboboat` in order to generate `package.xml` and `CMakeLists.txt` in `roboboat_tf` so it builds.